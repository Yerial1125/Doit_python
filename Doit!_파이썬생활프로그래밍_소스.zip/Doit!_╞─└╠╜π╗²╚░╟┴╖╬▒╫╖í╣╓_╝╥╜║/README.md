# Do it! 파이썬 생활 프로그래밍
- 2020.07 출간
- 저자 김창현(skytreesea@gmail.com)/출판사: 이지스퍼블리싱
- 계산기, 웹 크롤링, 드라마 대사 모으기, 통계처리, 아파트 실거래가 분석, 설문지 데이터 분석, 웹 크롤링 등.

* 저작권 고지: 개인 연습용으로 사용하는 것은 허락하지만 공중에 배포나 복사는 허락되지 않습니다. 
Copyright: Any redistribution and reproduction is prohibited without my written content. 
You can only use this for your personal practice. 
