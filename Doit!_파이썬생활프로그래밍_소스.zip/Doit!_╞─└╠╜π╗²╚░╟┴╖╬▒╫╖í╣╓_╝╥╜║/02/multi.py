# 19단 출력 프로그램 (Do it 파이썬 생활프로그래밍) 초판 2020: 42페이지
for item in range(2, 20):
    for each in range(2, 20):	
        print('%d X %d = %d' % (item, each, item * each))
